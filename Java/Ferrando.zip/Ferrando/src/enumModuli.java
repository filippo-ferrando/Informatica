public enum enumModuli {
    FOTOSENSORE,
    AUDIOSENSORE,
}
