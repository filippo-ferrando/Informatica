public enum Tipologia {
    FOTOSENSORI,
    AUDIOSENSORI;
}
